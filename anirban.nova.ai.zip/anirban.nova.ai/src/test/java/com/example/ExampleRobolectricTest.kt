package com.example

import android.Manifest
import android.app.Application
import android.content.Intent
import android.content.pm.PackageManager
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.ai.LanguageDetector
import com.example.ai.OfflineCommandEngine
import com.example.ai.SensitiveActionRequest
import com.example.ai.WakeWordParser
import com.example.data.local.ChatMessageEntity
import com.example.data.local.NoteEntity
import com.example.data.local.NovaDatabase
import com.example.data.local.NovaLocalRepository
import com.example.data.preferences.NovaThemeMode
import com.example.data.preferences.UserPreferencesRepository
import com.example.device.DeviceStatsProvider
import com.example.device.PhoneController
import com.example.service.NovaVoiceService
import com.example.service.WakeEngineMode
import com.example.voice.HeyNovaKeywordSpotter
import com.example.voice.KwsJsonParser
import com.example.voice.KwsModelState
import com.example.voice.VoiceCommandManager
import com.example.voice.VoiceIntentAction
import com.example.voice.VoskModelManager
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.test.runTest
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.Robolectric
import org.robolectric.RobolectricTestRunner
import org.robolectric.Shadows
import org.robolectric.annotation.Config
import java.io.File

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var app: Application
    private lateinit var db: NovaDatabase
    private lateinit var localRepo: NovaLocalRepository

    @Before
    fun setup() {
        app = ApplicationProvider.getApplicationContext()
        db = Room.inMemoryDatabaseBuilder(app, NovaDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        localRepo = NovaLocalRepository(db)
    }

    @After
    fun tearDown() {
        db.close()
    }

    @Test
    fun `app identity wake response and removed overlay permission match spec`() {
        assertEquals("NOVA AI", app.getString(R.string.app_name))
        assertEquals(
            "Yes, I'm listening. How can I help you?",
            app.getString(R.string.nova_wake_response)
        )

        val pkgInfo = app.packageManager.getPackageInfo(
            app.packageName,
            PackageManager.GET_PERMISSIONS
        )
        val requested = pkgInfo.requestedPermissions?.toList().orEmpty()
        assertFalse(
            "SYSTEM_ALERT_WINDOW must be completely removed",
            requested.contains(Manifest.permission.SYSTEM_ALERT_WINDOW)
        )
        assertTrue(
            "RECORD_AUDIO permission must be declared for voice wake word",
            requested.contains(Manifest.permission.RECORD_AUDIO)
        )
    }

    @Test
    fun `wake word parser activates on Hey NOVA and NOVA and extracts command`() {
        val heyNova = WakeWordParser.parse("Hey NOVA")
        assertTrue(heyNova.wakeDetected)
        assertTrue(heyNova.isBareWakeWord)

        val bareNova = WakeWordParser.parse("Nova")
        assertTrue(bareNova.wakeDetected)
        assertTrue(bareNova.isBareWakeWord)

        val bn = WakeWordParser.parse("নোভা")
        assertTrue(bn.wakeDetected)
        assertTrue(bn.isBareWakeWord)

        val bnCmd = WakeWordParser.parse("Nova, YouTube খোলো।")
        assertTrue(bnCmd.wakeDetected)
        assertFalse(bnCmd.isBareWakeWord)
        assertEquals("YouTube খোলো।", bnCmd.strippedCommand)

        val heyCmd = WakeWordParser.parse("Hey Nova, open WhatsApp")
        assertTrue(heyCmd.wakeDetected)
        assertFalse(heyCmd.isBareWakeWord)
        assertEquals("open WhatsApp", heyCmd.strippedCommand)

        val nonWake = WakeWordParser.parse("open Chrome")
        assertFalse(nonWake.wakeDetected)
    }

    @Test
    fun `language detector distinguishes Bengali Hindi and English`() {
        assertEquals("bn", LanguageDetector.detectLanguage("YouTube খোলো।"))
        assertEquals("hi", LanguageDetector.detectLanguage("मेरा बैटरी कितना है?"))
        assertEquals("en", LanguageDetector.detectLanguage("Open WhatsApp"))
    }

    @Test
    fun `voice service enforces microphone permission before starting`() {
        val shadowApp = Shadows.shadowOf(app)
        shadowApp.denyPermissions(Manifest.permission.RECORD_AUDIO)

        val startedWithoutPerm = NovaVoiceService.start(app)
        assertFalse(startedWithoutPerm)
        assertTrue(NovaVoiceService.statusMessage.value.contains("Permission denied", ignoreCase = true))

        shadowApp.grantPermissions(Manifest.permission.RECORD_AUDIO)
        val startedWithPerm = NovaVoiceService.start(app)
        assertTrue(startedWithPerm)
        val nextIntent = shadowApp.nextStartedService
        assertNotNull(nextIntent)
        assertEquals(NovaVoiceService::class.java.name, nextIntent.component?.className)
    }

    @Test
    fun `offline engine handles math notification gating app launch and security`() = runTest {
        val engine = OfflineCommandEngine(
            context = app,
            statsProvider = DeviceStatsProvider(app),
            phoneController = PhoneController(app),
            localRepo = localRepo
        )

        val math = engine.tryHandleCommand("Calculate (15 + 5) * 4", "en", isDeviceLocked = false, forceOffline = true)
        assertTrue(math.handled)
        assertTrue(math.replyText.contains("80"))

        val lockedTime = engine.tryHandleCommand("What time is it", "en", isDeviceLocked = true, forceOffline = true)
        assertTrue(lockedTime.handled)
        assertFalse(lockedTime.lockScreenRestricted)

        val lockedSensitive = engine.tryHandleCommand("call Mom", "en", isDeviceLocked = true, forceOffline = true)
        assertTrue(lockedSensitive.handled)
        assertTrue(lockedSensitive.lockScreenRestricted)

        val unlockedCall = engine.tryHandleCommand("call 1234567890", "en", isDeviceLocked = false, forceOffline = true)
        assertTrue(unlockedCall.handled)
        assertNotNull(unlockedCall.sensitiveAction)
        assertTrue(unlockedCall.sensitiveAction is SensitiveActionRequest.MakeCall)

        // Notification reading must refuse cleanly when Notification Access is not granted
        val notifReply = engine.tryHandleCommand("read my notifications", "en", isDeviceLocked = false, forceOffline = true)
        assertTrue(notifReply.handled)
        assertTrue(notifReply.replyText.contains("Notification Access", ignoreCase = true))

        // App launching via PackageManager / Intent resolution
        val shadowPm = Shadows.shadowOf(app.packageManager)
        val waResolve = android.content.pm.ResolveInfo().apply {
            activityInfo = android.content.pm.ActivityInfo().apply {
                packageName = "com.whatsapp"
                name = "com.whatsapp.Main"
                nonLocalizedLabel = "WhatsApp"
            }
        }
        shadowPm.addResolveInfoForIntent(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setPackage("com.whatsapp"),
            waResolve
        )
        shadowPm.addResolveInfoForIntent(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER),
            waResolve
        )

        val openWa = engine.tryHandleCommand("open WhatsApp", "en", isDeviceLocked = false, forceOffline = true)
        assertTrue(openWa.handled)
        assertTrue(openWa.replyText.contains("Opening", ignoreCase = true))

        val openSettings = engine.tryHandleCommand("open Settings", "en", isDeviceLocked = false, forceOffline = true)
        assertTrue(openSettings.handled)
        assertTrue(openSettings.replyText.contains("settings", ignoreCase = true))
    }

    @Test
    fun `room database persists messages and notes locally`() = runTest {
        localRepo.addMessage(ChatMessageEntity(role = "user", content = "Hey Nova", languageCode = "en"))
        localRepo.saveNote("Shopping", "Milk and coffee")

        val messages = localRepo.messages.first()
        val notes: List<NoteEntity> = localRepo.notes.first()

        assertEquals(1, messages.size)
        assertEquals("Hey Nova", messages.first().content)
        assertEquals(1, notes.size)
        assertEquals("Shopping", notes.first().title)
    }

    @Test
    fun `vosk kws json parser detects Hey NOVA and rejects unknown grammar tokens`() {
        assertEquals("hey nova", KwsJsonParser.extractDetectedKeyword("""{"text": "hey nova"}"""))
        assertEquals("hey nova", KwsJsonParser.extractDetectedKeyword("""{"partial": "hey nova"}"""))
        assertEquals("nova", KwsJsonParser.extractDetectedKeyword("""{"text": "[unk] nova"}"""))
        assertEquals("ok nova", KwsJsonParser.extractDetectedKeyword("""{"partial": "ok nova"}"""))
        assertNull(KwsJsonParser.extractDetectedKeyword("""{"text": "[unk]"}"""))
        assertNull(KwsJsonParser.extractDetectedKeyword("""{"partial": ""}"""))
        assertNull(KwsJsonParser.extractDetectedKeyword("""not valid json"""))

        val silent = ShortArray(160) { 0 }
        assertEquals(0f, KwsJsonParser.computeNormalizedRms(silent, silent.size), 0.001f)

        val speech = ShortArray(160) { 6553 } // ~0.2 full-scale amplitude
        assertTrue(KwsJsonParser.computeNormalizedRms(speech, speech.size) > 0.5f)
    }

    @Test
    fun `vosk model manager validates model directory structure and cleans up`() {
        VoskModelManager.deleteModel(app)
        assertTrue(VoskModelManager.refreshState(app) is KwsModelState.NotDownloaded)

        val modelDir = VoskModelManager.getModelDir(app)
        File(modelDir, "conf").mkdirs()
        File(modelDir, "am").mkdirs()
        File(modelDir, "conf/model.conf").writeText("# model config")
        // Missing am/final.mdl -> still invalid
        assertFalse(VoskModelManager.isValidModelDirectory(modelDir))

        File(modelDir, "am/final.mdl").writeBytes(byteArrayOf(1, 2, 3))
        assertTrue(VoskModelManager.isValidModelDirectory(modelDir))
        assertTrue(VoskModelManager.refreshState(app) is KwsModelState.Ready)

        VoskModelManager.deleteModel(app)
        assertTrue(VoskModelManager.refreshState(app) is KwsModelState.NotDownloaded)
    }

    @Test
    fun `keyword spotter and foreground mic service enforce RECORD_AUDIO and stop cleanly`() {
        val shadowApp = Shadows.shadowOf(app)
        shadowApp.denyPermissions(Manifest.permission.RECORD_AUDIO)

        val spotter = HeyNovaKeywordSpotter(app)
        var capturedError = ""
        val startedSpotter = spotter.start(
            modelDir = VoskModelManager.getModelDir(app),
            onKeywordDetected = {},
            onError = { capturedError = it }
        )
        assertFalse(startedSpotter)
        assertTrue(capturedError.contains("Permission denied", ignoreCase = true))
        spotter.release()

        // Verify foreground service lifecycle when RECORD_AUDIO is granted
        shadowApp.grantPermissions(Manifest.permission.RECORD_AUDIO)
        val controller = Robolectric.buildService(NovaVoiceService::class.java).create()
        val service = controller.get()
        service.onStartCommand(Intent(app, NovaVoiceService::class.java), 0, 1)
        assertTrue(NovaVoiceService.isRunning.value)

        // Stop action terminates foreground service and resets engine mode
        service.onStartCommand(
            Intent(app, NovaVoiceService::class.java).apply { action = NovaVoiceService.ACTION_STOP },
            0,
            2
        )
        controller.destroy()
        assertFalse(NovaVoiceService.isRunning.value)
        assertEquals(WakeEngineMode.INACTIVE, NovaVoiceService.engineMode.value)
    }

    @Test
    fun `brightness voice command requests Modify System Settings permission gracefully when denied`() = runTest {
        val engine = OfflineCommandEngine(
            context = app,
            statsProvider = DeviceStatsProvider(app),
            phoneController = PhoneController(app),
            localRepo = localRepo
        )
        val outcome = engine.tryHandleCommand(
            rawInput = "set brightness to 80%",
            languageCode = "en",
            isDeviceLocked = false,
            forceOffline = true
        )
        assertTrue(outcome.handled)
        if (!android.provider.Settings.System.canWrite(app)) {
            assertEquals(80, outcome.requiresWriteSettingsForBrightness)
            assertTrue(outcome.replyText.contains("Modify System Settings", ignoreCase = true))
        }
    }

    @Test
    fun `voice command manager builds and dispatches Android intents for WhatsApp Settings and Alarms`() {
        val manager = VoiceCommandManager(app)

        // 1. Open Settings
        val settingsResult = manager.handleCommand("Open Settings", languageCode = "en", isDeviceLocked = false)
        assertTrue(settingsResult.handled)
        assertTrue(settingsResult.success)
        assertEquals(android.provider.Settings.ACTION_SETTINGS, settingsResult.launchedIntent?.action)

        // 2. Open Wi-Fi Settings
        val wifiAction = manager.parseCommand("Hey NOVA, open Wi-Fi settings")
        assertTrue(wifiAction is VoiceIntentAction.OpenSettings)
        assertEquals(
            android.provider.Settings.ACTION_WIFI_SETTINGS,
            (wifiAction as VoiceIntentAction.OpenSettings).settingsAction
        )

        // 3. Set an alarm with PM conversion (6:30 PM -> 18:30)
        val alarmResult = manager.handleCommand("Set an alarm for 6:30 PM", languageCode = "en", isDeviceLocked = true)
        assertTrue(alarmResult.handled)
        assertTrue(alarmResult.success)
        assertFalse(alarmResult.lockScreenRestricted)
        assertEquals(android.provider.AlarmClock.ACTION_SET_ALARM, alarmResult.launchedIntent?.action)
        assertEquals(18, alarmResult.launchedIntent?.getIntExtra(android.provider.AlarmClock.EXTRA_HOUR, -1))
        assertEquals(30, alarmResult.launchedIntent?.getIntExtra(android.provider.AlarmClock.EXTRA_MINUTES, -1))

        // 4. Open WhatsApp (registered in ShadowPackageManager)
        val shadowPm = Shadows.shadowOf(app.packageManager)
        val waResolve = android.content.pm.ResolveInfo().apply {
            activityInfo = android.content.pm.ActivityInfo().apply {
                packageName = "com.whatsapp"
                name = "com.whatsapp.Main"
                nonLocalizedLabel = "WhatsApp"
            }
        }
        shadowPm.addResolveInfoForIntent(
            Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER).setPackage("com.whatsapp"),
            waResolve
        )

        val lockedWa = manager.handleCommand("Open WhatsApp", languageCode = "en", isDeviceLocked = true)
        assertTrue(lockedWa.handled)
        assertTrue(lockedWa.lockScreenRestricted)

        val unlockedWa = manager.handleCommand("Open WhatsApp", languageCode = "en", isDeviceLocked = false)
        assertTrue(unlockedWa.handled)
        assertTrue(unlockedWa.success)
        assertEquals("com.whatsapp", unlockedWa.launchedIntent?.component?.packageName)

        // 5. Open Camera intent
        val camAction = manager.parseCommand("Open Camera")
        assertEquals(VoiceIntentAction.OpenCamera, camAction)
        val camIntent = manager.buildIntent(VoiceIntentAction.OpenCamera)
        assertEquals(android.provider.MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA, camIntent?.action)
    }

    @Test
    fun `theme mode preference defaults to dark futuristic and persists light toggle`() = runTest {
        val prefsRepo = UserPreferencesRepository(app)
        val initial = prefsRepo.preferencesFlow.first()
        assertEquals(NovaThemeMode.DARK, initial.themeMode)

        prefsRepo.setThemeMode(NovaThemeMode.LIGHT)
        assertEquals(NovaThemeMode.LIGHT, prefsRepo.preferencesFlow.first().themeMode)

        prefsRepo.setThemeMode(NovaThemeMode.DARK)
        assertEquals(NovaThemeMode.DARK, prefsRepo.preferencesFlow.first().themeMode)
    }
}
